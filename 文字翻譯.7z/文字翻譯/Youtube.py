from youtube_transcript_api import YouTubeTranscriptApi
from googletrans import Translator
import time

def get_youtube_transcript(video_id):
    try:
        # 抓取日文字幕
        transcript = YouTubeTranscriptApi.get_transcript(video_id, languages=['ja'])
        return transcript
    except Exception as e:
        print(f"抓取日文字幕失敗: {e}")
        return None

def translate_to_chinese(transcript):
    translator = Translator()
    translated_lines = []
    
    for line in transcript:
        text = line['text']
        for attempt in range(3):  # 最多重試 3 次
            try:
                # 翻譯成中文（簡體）
                translated_text = translator.translate(text, dest='zh-cn').text
                translated_lines.append({
                    'start': line['start'],
                    'duration': line['duration'],
                    'original': text,
                    'translated': translated_text
                })
                break  # 成功就跳出重試迴圈
            except Exception as e:
                print(f"翻譯失敗 (嘗試 {attempt+1}/3): {e}")
                if attempt < 2:  # 如果不是最後一次嘗試
                    time.sleep(2)  # 等待 2 秒後重試
                continue
    
    return translated_lines

def save_to_file(translated_lines, filename="translated_subtitles.txt"):
    with open(filename, 'w', encoding='utf-8') as f:
        for line in translated_lines:
            f.write(f"[{line['start']}] {line['original']} -> {line['translated']}\n")
    print(f"翻譯結果已儲存到 {filename}")

if __name__ == "__main__":
    video_id = input("請輸入 YouTube 影片 ID: ")
    transcript = get_youtube_transcript(video_id)
    if not transcript:
        print("無法繼續，因為沒有抓到日文字幕。")
    else:
        translated = translate_to_chinese(transcript)
        if translated:
            for line in translated:
                print(f"[{line['start']}] {line['original']} -> {line['translated']}")
            save_to_file(translated)