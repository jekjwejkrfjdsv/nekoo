document.addEventListener('DOMContentLoaded', () => {
    console.log("popup.js 已加載"); // 添加檢查點
    const startButton = document.getElementById('startButton');
    const stopButton = document.getElementById('stopButton');
    const translationsDiv = document.getElementById('translations');

    if (!startButton || !stopButton || !translationsDiv) {
        console.error("DOM 元素未找到");
        return;
    }

    startButton.addEventListener('click', () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (!tabs[0]) {
                console.error("未找到活動標籤");
                return;
            }
            chrome.tabs.sendMessage(tabs[0].id, { action: "start" }, (response) => {
                if (chrome.runtime.lastError) {
                    console.error("消息發送失敗：", chrome.runtime.lastError);
                    alert("無法啟動：請確保在 YouTube 頁面");
                    return;
                }
                if (response && response.status === "recording") {
                    startButton.disabled = true;
                    stopButton.disabled = false;
                } else if (response && response.error) {
                    alert("錄音啟動失敗：" + response.error);
                }
            });
        });
    });

    stopButton.addEventListener('click', () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            chrome.tabs.sendMessage(tabs[0].id, { action: "stop" }, (response) => {
                if (response && response.status === "stopped") {
                    startButton.disabled = false;
                    stopButton.disabled = true;
                }
            });
        });
    });

    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.transcript && message.translated) {
            const entry = document.createElement('div');
            entry.className = 'translation-entry';
            entry.innerHTML = `<strong>原始文字（日文）：</strong>${message.transcript}<br><strong>翻譯（中文）：</strong>${message.translated}`;
            translationsDiv.appendChild(entry);
            translationsDiv.scrollTop = translationsDiv.scrollHeight;
        } else if (message.error) {
            alert('發生錯誤：' + message.error);
            startButton.disabled = false;
            stopButton.disabled = true;
        }
    });
});