const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (!SpeechRecognition) {
    console.log("瀏覽器不支援語音識別");
} else {
    const recognition = new SpeechRecognition();
    recognition.lang = 'ja-JP'; // 日文
    recognition.interimResults = false;

    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === "start") {
            recognition.start();
            console.log("開始錄音（麥克風捕捉 YouTube 聲音）...");
            sendResponse({ status: "recording" });
        } else if (message.action === "stop") {
            recognition.stop();
            console.log("停止錄音");
            sendResponse({ status: "stopped" });
        }
    });

    recognition.onresult = async (event) => {
        const transcript = event.results[0][0].transcript;
        const translated = await translateText(transcript);
        chrome.runtime.sendMessage({
            transcript: transcript,
            translated: translated
        });
    };

    recognition.onerror = (event) => {
        if (event.error !== 'no-speech') {
            console.error('語音識別錯誤：', event.error);
            chrome.runtime.sendMessage({ error: event.error });
        }
    };

    recognition.onend = () => {
        console.log("語音識別結束");
    };
}

async function translateText(text) {
    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=ja|zh-CN`;
    try {
        const response = await fetch(url);
        const data = await response.json();
        return data.responseData.translatedText || '翻譯失敗';
    } catch (error) {
        console.error('翻譯錯誤：', error);
        return '翻譯失敗';
    }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("收到消息：", message); // 添加這行
    if (message.action === "start") {
        recognition.start();
        console.log("開始錄音（麥克風捕捉 YouTube 聲音）...");
        sendResponse({ status: "recording" });
    } else if (message.action === "stop") {
        recognition.stop();
        console.log("停止錄音");
        sendResponse({ status: "stopped" });
    }
});